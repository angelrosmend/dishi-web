export { default as almohadas } from './almohadas.jpg'
export { default as bebes } from './bebes.jpg'
export { default as circulo1 } from './circulo1.jpg'
export { default as circulo2 } from './circulo2.jpg'
export { default as circulo3 } from './circulo3.jpg'
export { default as circulo4 } from './circulo4.jpg'
export { default as circulo5 } from './circulo5.jpg'
export { default as circulo6 } from './circulo6.jpg'
export { default as imagen1 } from './imagen1.jpg'
export { default as imagen2 } from './imagen2.jpg'
export { default as imagen3 } from './imagen3.jpg'
export { default as imagen4 } from './imagen4.jpg'
export { default as imagen5 } from './imagen5.jpg'
export { default as img } from './img.jpg'
export { default as img1 } from './img1.jpg'
export { default as img2 } from './img2.jpg'
export { default as jabon } from './Jabon4.jpg'
export { default as jamon } from './jamon.jpg'
export { default as logoDishi } from './logodishi.png'
export { default as perro } from './perro.jpg'
export { default as plantas } from './plantas.jpg'
export { default as reloj } from './reloj.jpg'
export { default as slider } from './slider11.jpg'
export { default as veggie } from './veggie.jpg'









