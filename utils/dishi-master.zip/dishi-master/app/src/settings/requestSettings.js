export const url = 'http://pehuajo.clickaut.com/clickautwebapi/api/V2Home/getData';

export const config = {
        "PaginationSettings": [
            {
                "Id": 0,
                "PageFrom": 0,
                "PageCount": 10
            },
            {
                "Id": 1,
                "PageFrom": 0,
                "PageCount": 10
            },
            {
                "Id": 2,
                "PageFrom": 0,
                "PageCount": 10
            },
            {
                "Id": 3,
                "PageFrom": 0,
                "PageCount": 10
            },
            {
                "Id": 4,
                "PageFrom": 0,
                "PageCount": 10
            },
            {
                "Id": 5,
                "PageFrom": 0,
                "PageCount": 10
            },
            {
                "Id": 6,
                "PageFrom": 0,
                "PageCount": 10
            }
        ],
        "MobileUser": {
            "Id": 0,
            "Email": "",
            "RolId": 0
        },
        "orderby": null,
        "Filter": {
            "Text": ""
        },
        "APP_ConfigurationID": "21020",
        "Platform": "Browser",
        "AppVersion": "",
        "AppDebug": false,
        "Fecha": "2020-05-27T18:45:13.958Z",
        "IdSucursal": 0,
        "IdSucursalCompra": 0,
        "ModeEmpresas": false,
        "MobileMonoMarca": false,
        "IdEmpresa": 0,
        "ReadCountMode": false,
        "PageFrom": 0,
        "PageCount": 10,
        "CalculateTotalRows": false
       
}